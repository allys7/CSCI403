1. Ally Smith, no collaborators
2. The main issues I had with this project were with the joins, but after some fiddling I figured out my mistake.
3. I liked that the assignment was related to computer science history.
4. I spent about an hour and a half on this assignment.
5. Nothing to add/fix