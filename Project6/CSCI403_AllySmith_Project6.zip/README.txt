1.  Ally Smith, no collaborators.
2.  The biggest challenge I faced in this project was adding the derived value
    for the `views` attribute. In the end, I worked out a subquery to calculate
    each reviewer's total views and created a VIEW that joined this with the
    reviewer table.
3.  I liked how clearly laid out the instructions were for expected values of
    each attribute, but that things like data types were not explicitly given.
4.  I spent 3-4 hours on this project.